AI transcriptions of twelve page scans from Alexandre Pillon's collection of siege telegrams and pigeongrammes (Paris, 1870-71).
Scans: collection of Alexandre Pillon, published here with his permission. Transcription: Claude (Anthropic), read from the images and
checked against Pillon's own hand transcription on one pilot telegram (271 of 283 groups exactly right, 95.8%).
These are AI readings, about 96% right per group, NOT verified. Four spots cannot be read from these scans (one Favre block of the
23 October page, the top 14 lines of 2emeS_32 block 1, the lower part of one small block, one blurry block) and page
2emeS_20-recto is unreadable. "?" marks a digit or group the reader could not settle. Rows marked "merged" combine two independent re-reads.
out/    first-pass transcription of each page, one file per page, one line per printed line, groups separated by spaces
reread/ merged re-reads of the weak blocks (files *_merged.txt)
Pillon's repertoires R1, R2, R3 and his Excel files are his own unpublished work and are not included.
Licence: the transcription text CC BY 4.0, the underlying scans (c) Alexandre Pillon.
